from pathlib import Path
import argparse,csv,sys,json,numpy as np
from scipy.stats import spearmanr
sys.path.insert(0,str(Path(__file__).parent)); from aads import solve
ap=argparse.ArgumentParser(); ap.add_argument("--suite",required=True); ap.add_argument("--output",required=True); a=ap.parse_args(); out=Path(a.output); out.mkdir(parents=True,exist_ok=True); rows=[]
for p in sorted(Path(a.suite).glob("*.json")):
 d=json.loads(p.read_text()); r=solve(p,2000 if d["metadata"]["n"]==200 else None); rows.append([p.stem,d["metadata"]["n"],d["metadata"]["strength"],d["metadata"]["rep"],r["objective"],r["expanded"],r["status"]])
with (out/"synergy_results.csv").open("w",newline="") as f: w=csv.writer(f); w.writerow(["instance","nodes","strength","replicate","objective","expanded","status"]); w.writerows(rows)
card=np.array([2 if x[1]<=50 else 3 if x[1]<=100 else 4 for x in rows]); rho,p=spearmanr(card,np.array([x[5] for x in rows])); (out/"statistics.json").write_text(json.dumps({"spearman_rho":float(rho),"p":float(p)},indent=2))
print("Wrote synergy results and statistics.")
