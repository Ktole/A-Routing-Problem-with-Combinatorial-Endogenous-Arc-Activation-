from pathlib import Path
import argparse,json
ap=argparse.ArgumentParser(); ap.add_argument("--output",required=True); a=ap.parse_args(); out=Path(a.output); out.mkdir(parents=True,exist_ok=True)
for n in [20,50,100,200]:
 for strength,sav in [("weak",.08),("moderate",.20),("strong",.35)]:
  for rep in range(1,6):
   k=2 if n<=50 else 3 if n<=100 else 4; nodes=[str(i) for i in range(n)]; base=[{"id":f"b{i}","u":str(i),"v":str(i+1),"cost":1.0} for i in range(n-1)]; acts=[]
   for j in range(k):
    x=f"x{j}"; nodes.append(x); q=f"a{j}"; acts.append(q); c=2+j
    base += [{"id":f"o{j}","u":str(c),"v":x,"cost":2.0,"action":q},{"id":f"r{j}","u":x,"v":str(c),"cost":2.0}]
   u=2+k; lc=max(.1,(n-1)*(1-sav)-u-4*k)
   d={"name":f"SYN-N{n}-{strength}-R{rep}","nodes":nodes,"origin":"0","destination":str(n-1),"base_arcs":base,"latent_arcs":[{"id":"e1","u":str(u),"v":str(n-1),"cost":lc}],"activation_rules":{"e1":[acts]},"metadata":{"n":n,"strength":strength,"rep":rep}}
   (out/f'{d["name"]}.json').write_text(json.dumps(d,indent=2))
print("Generated 60 instances.")
