from pathlib import Path
import json
p=Path("application_case/emergency_access");p.mkdir(parents=True,exist_ok=True)
d={"static_minutes":61,"ceaa_minutes":48,"saving_minutes":13,"saving_pct":21.311,"activated_connection_minutes":4,"note":"Illustrative planning assumptions; not field-calibrated measurements."}
(p/"case.json").write_text(json.dumps(d,indent=2));print(p/"case.json")
