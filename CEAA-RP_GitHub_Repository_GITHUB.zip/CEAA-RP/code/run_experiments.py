from pathlib import Path
import argparse,csv,sys,json
sys.path.insert(0,str(Path(__file__).parent)); from aads import solve
ap=argparse.ArgumentParser(); ap.add_argument("--bench",required=True); ap.add_argument("--output",required=True); a=ap.parse_args(); out=Path(a.output); out.mkdir(parents=True,exist_ok=True); rows=[]
for p in sorted(Path(a.bench).glob("*.json")):
 r=solve(p,80 if "-L-" in p.name else 250 if "-M-" in p.name else None); rows.append([p.stem,r["objective"],r["expanded"],r["cap_deletions"],r["status"]])
with (out/"ceaa_results.csv").open("w",newline="") as f: w=csv.writer(f); w.writerow(["instance","objective","expanded","cap_deletions","status"]); w.writerows(rows)
print("Wrote",len(rows),"results.")
