# Independent exact expanded-state validator (kept separate from AADS dominance logic).
from pathlib import Path
import argparse,heapq,itertools,json,csv
def exact(p):
 d=json.loads(Path(p).read_text()); lat={x["id"] for x in d.get("latent_arcs",[])}; rules={k:[frozenset(y) for y in v] for k,v in d.get("activation_rules",{}).items()}; adj={}
 for x in d["base_arcs"]+d.get("latent_arcs",[]): adj.setdefault(str(x["u"]),[]).append(x)
 s,t=str(d["origin"]),str(d["destination"]); q=[(0,0,s,frozenset())]; best={(s,frozenset()):0}; c=itertools.count()
 while q:
  g,_,v,H=heapq.heappop(q)
  if v==t:return g
  if g!=best[(v,H)]:continue
  for x in adj.get(v,[]):
   if x["id"] in lat and not any(r<=H for r in rules.get(x["id"],[])):continue
   H2=frozenset(H|({x["action"]} if x.get("action") else set())); u=str(x["v"]); ng=g+float(x["cost"])
   if ng<best.get((u,H2),float("inf")):best[(u,H2)]=ng;heapq.heappush(q,(ng,next(c),u,H2))
 return float("inf")
ap=argparse.ArgumentParser(); ap.add_argument("--project",default="."); ap.add_argument("--output",required=True); a=ap.parse_args(); out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
files=list((Path(a.project)/"benchmarks/CEAA-Bench-v1.0").glob("CEAA-S-*.json"))[:10]+list((Path(a.project)/"benchmarks/CEAA-Synergy-v2").glob("SYN-N20-*.json"))[:15]
with (out/"exact_validation.csv").open("w",newline="") as f:w=csv.writer(f);w.writerow(["instance","exact_objective"]);[w.writerow([p.stem,exact(p)]) for p in files]
print("Validated",len(files),"instances.")
