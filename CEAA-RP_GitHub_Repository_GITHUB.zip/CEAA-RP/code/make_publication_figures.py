from pathlib import Path
import pandas as pd,matplotlib.pyplot as plt
p=Path("results/synergy_results.csv")
if p.exists():
 d=pd.read_csv(p);g=d.groupby("nodes")["expanded"].mean();fig,ax=plt.subplots();ax.plot(g.index,g.values,marker="o");ax.set_xlabel("Nodes");ax.set_ylabel("Mean labels expanded");fig.tight_layout();Path("figures").mkdir(exist_ok=True);fig.savefig("figures/search_effort.png",dpi=300)
else: print("Run synergy experiments first.")
