from pathlib import Path
import json,heapq,itertools,math
def load(p):
 d=json.loads(Path(p).read_text()); arcs=d["base_arcs"]+d.get("latent_arcs",[])
 latent={a["id"] for a in d.get("latent_arcs",[])}
 rules={k:[frozenset(x) for x in v] for k,v in d.get("activation_rules",{}).items()}
 return d,arcs,latent,rules
def solve(p,cap=None):
 d,arcs,latent,rules=load(p); s=str(d["origin"]); t=str(d["destination"]); adj={}
 for a in arcs: adj.setdefault(str(a["u"]),[]).append(a)
 pq=[(0,next(itertools.count()),s,frozenset(),[])]; labels={s:[(frozenset(),0.)]}; inc=float("inf"); best=[]; deleted=expanded=0; c=itertools.count()
 while pq:
  g,_,v,H,path=heapq.heappop(pq)
  if g>=inc: continue
  expanded+=1
  for a in adj.get(v,[]):
   if a["id"] in latent and not any(r<=H for r in rules.get(a["id"],[])): continue
   ng=g+float(a["cost"]); H2=frozenset(H|({a["action"]} if a.get("action") else set())); u=str(a["v"])
   if ng>=inc: continue
   if any(g0<=ng and H0>=H2 for H0,g0 in labels.get(u,[])): continue
   L=[x for x in labels.get(u,[]) if not (ng<=x[1] and H2>=x[0])]+[(H2,ng)]
   if cap and len(L)>cap:
    L.sort(key=lambda x:x[1]); deleted+=len(L)-cap; L=L[:cap]
    if (H2,ng) not in L: labels[u]=L; continue
   labels[u]=L; np=path+[a["id"]]
   if u==t: inc,best=ng,np
   else: heapq.heappush(pq,(ng,next(c),u,H2,np))
 return {"objective":inc,"route":best,"expanded":expanded,"cap_deletions":deleted,"status":"optimal" if deleted==0 else "feasible"}
