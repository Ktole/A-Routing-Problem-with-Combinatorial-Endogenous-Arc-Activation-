# CEAA-RP benchmark notes
A latent arc e is available for history H iff at least one prerequisite set A_e^k is contained in H.
History is monotone and actions completed during a transition enter the next state.

AADS labels are `(node, history, accumulated_cost)`. At the same node, `(H1,g1)` dominates
`(H2,g2)` when `g1 <= g2` and `H1` is a superset of `H2`.

If a per-node cap deletes a label, report the result as `feasible`, not `optimal`.
