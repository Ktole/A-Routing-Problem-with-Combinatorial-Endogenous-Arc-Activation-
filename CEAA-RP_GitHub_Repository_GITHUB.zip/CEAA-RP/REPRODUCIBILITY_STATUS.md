# Reproducibility status

The computational workflow, benchmark generation, solver outputs, validation workflow,
and reported manuscript results have been verified by the author.

**Release status:** Verified reproducibility package.

For archival citation, create a tagged GitHub release and archive that exact release in Zenodo.
