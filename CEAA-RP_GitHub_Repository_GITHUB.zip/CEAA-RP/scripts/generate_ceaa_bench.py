from pathlib import Path
import argparse,json,random
def make(n,seed,name):
 r=random.Random(seed); base=[]; coords={str(i):[i,0] for i in range(n)}
 for i in range(n-1): base.append({"id":f"b{i}","u":str(i),"v":str(i+1),"cost":10+r.random()})
 actions=[]
 for j,node in enumerate(range(1,min(4,n-2)),1):
  x=f"x{j}"; coords[x]=[node,2]; q=f"a{j}"; actions.append(q)
  base += [{"id":f"o{j}","u":str(node),"v":x,"cost":2.5,"action":q},{"id":f"r{j}","u":x,"v":str(node),"cost":2.5}]
 latent=[{"id":"e1","u":str(n//3),"v":str(2*n//3),"cost":max(1,n*1.5)}]
 return {"name":name,"nodes":list(coords),"origin":"0","destination":str(n-1),"coordinates":coords,"base_arcs":base,"latent_arcs":latent,"activation_rules":{"e1":[actions[:2]]},"seed":seed}
ap=argparse.ArgumentParser(); ap.add_argument("--output",required=True); a=ap.parse_args(); out=Path(a.output); out.mkdir(parents=True,exist_ok=True)
sizes=[10,12,14,15,16,18,19,20,22,25,32,40,48,56,64,72,80,88,96,100,120,150,180,210,240,280,320,350,380,400]
for i,n in enumerate(sizes):
 cls="S" if i<10 else "M" if i<20 else "L"; d=make(n,20260916+i,f"CEAA-{cls}-{i%10+1:02d}"); (out/f'{d["name"]}.json').write_text(json.dumps(d,indent=2))
print("Generated 30 instances.")
