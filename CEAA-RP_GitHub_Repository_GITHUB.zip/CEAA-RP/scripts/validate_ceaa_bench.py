from pathlib import Path
import argparse,json,hashlib
ap=argparse.ArgumentParser(); ap.add_argument("bench"); a=ap.parse_args(); root=Path(a.bench); m=[]
for p in sorted(root.glob("*.json")):
 d=json.loads(p.read_text()); assert d["origin"] in d["nodes"] and d["destination"] in d["nodes"]
 m.append({"file":p.name,"sha256":hashlib.sha256(p.read_bytes()).hexdigest()})
(root/"manifest.json").write_text(json.dumps(m,indent=2)); print("Validated",len(m),"instances.")
