# GitHub and Zenodo instructions
1. Create a public GitHub repository named `CEAA-RP`.
2. Extract this ZIP and upload the contents of the `CEAA-RP` folder.
3. The computational results have been verified against the manuscript.
4. Replace the GitHub placeholder in `CITATION.cff` with the public repository URL.
5. Commit and create GitHub release/tag `v1.0.0`.
6. Connect the repository to Zenodo and archive that release.
7. Put the minted Zenodo DOI in `CITATION.cff` and in the manuscript.
8. Keep the submitted release immutable; publish later corrections as a new version.
