#!/usr/bin/env python3
"""Validate CEAA-Bench v1.0 schemas, graph reachability, and recorded solutions."""

from __future__ import annotations

import csv
import json
import math
import sys
from pathlib import Path


def fail(message):
    raise AssertionError(message)


def validate_instance(folder: Path):
    meta = json.loads((folder / "metadata.json").read_text())
    activation = json.loads((folder / "activation.json").read_text())
    with (folder / "nodes.csv").open(newline="") as f:
        nodes = list(csv.DictReader(f))
    with (folder / "base_arcs.csv").open(newline="") as f:
        arcs = list(csv.DictReader(f))
    n = meta["dimension"]
    if len(nodes) != n:
        fail(f"{folder.name}: dimension mismatch")
    arc_keys = {(int(a["from"]), int(a["to"])) for a in arcs}
    if len(arc_keys) != len(arcs):
        fail(f"{folder.name}: duplicate base arcs")
    if any(float(a["cost"]) <= 0 for a in arcs):
        fail(f"{folder.name}: nonpositive base cost")
    latent_ids = {x["id"] for x in activation["latent_arcs"]}
    if len(latent_ids) != len(activation["latent_arcs"]):
        fail(f"{folder.name}: duplicate latent ID")
    for item in activation["latent_arcs"]:
        if (item["from"], item["to"]) in arc_keys:
            fail(f"{folder.name}: latent/base collision")
        if item["cost"] <= 0 or not item["activation_rules"]:
            fail(f"{folder.name}: invalid latent arc")
        for rule in item["activation_rules"]:
            if len(rule["all_of"]) < 2:
                fail(f"{folder.name}: activation must be combinatorial")
            for p in rule["all_of"]:
                if p["type"] == "traverse" and tuple(p["arc"]) not in arc_keys:
                    fail(f"{folder.name}: missing prerequisite base arc")
                if p["type"] == "traverse_latent" and p["latent_arc_id"] not in latent_ids:
                    fail(f"{folder.name}: missing prerequisite latent arc")
    baseline = json.loads((folder / "baseline_solution.json").read_text())
    route = baseline["route"]
    costs = {(int(a["from"]), int(a["to"])): float(a["cost"]) for a in arcs}
    objective = sum(costs[(u, v)] for u, v in zip(route, route[1:]))
    if not math.isclose(objective, baseline["objective"], abs_tol=1e-3):
        fail(f"{folder.name}: baseline objective mismatch")
    exact_file = folder / "ceaa_optimal_solution.json"
    if meta["size_class"] == "S" and not exact_file.exists():
        fail(f"{folder.name}: missing small exact solution")
    return meta["size_class"]


def main(root: Path):
    folders = sorted(p for p in (root / "instances").iterdir() if p.is_dir())
    if len(folders) != 30:
        fail(f"Expected 30 instances, found {len(folders)}")
    counts = {"S": 0, "M": 0, "L": 0}
    for folder in folders:
        counts[validate_instance(folder)] += 1
    if counts != {"S": 10, "M": 10, "L": 10}:
        fail(f"Unexpected class counts: {counts}")
    print(f"PASS: 30 instances validated ({counts})")


if __name__ == "__main__":
    main(Path(sys.argv[1] if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]))
