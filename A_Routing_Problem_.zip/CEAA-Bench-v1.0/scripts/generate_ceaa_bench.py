#!/usr/bin/env python3
"""Generate CEAA-Bench v1.0: routing with history-dependent arc activation."""

from __future__ import annotations

import argparse
import csv
import hashlib
import heapq
import json
import math
import random
import shutil
from dataclasses import asdict, dataclass
from pathlib import Path


MASTER_SEED = 20260916
VERSION = "1.0.0"


@dataclass(frozen=True)
class Arc:
    tail: int
    head: int
    cost: float


def distance(a: tuple[float, float], b: tuple[float, float]) -> float:
    return round(math.hypot(a[0] - b[0], a[1] - b[1]), 3)


def shortest_path(n: int, arcs: list[Arc], source: int, target: int):
    adj = [[] for _ in range(n)]
    for a in arcs:
        adj[a.tail].append((a.head, a.cost))
    dist = [math.inf] * n
    prev = [-1] * n
    dist[source] = 0.0
    pq = [(0.0, source)]
    while pq:
        d, u = heapq.heappop(pq)
        if d != dist[u]:
            continue
        if u == target:
            break
        for v, c in adj[u]:
            nd = round(d + c, 6)
            if nd < dist[v]:
                dist[v], prev[v] = nd, u
                heapq.heappush(pq, (nd, v))
    if math.isinf(dist[target]):
        raise RuntimeError("No baseline path")
    path, cur = [], target
    while cur != -1:
        path.append(cur)
        cur = prev[cur]
    return dist[target], list(reversed(path))


def make_nodes(n: int, rng: random.Random):
    nodes = []
    for i in range(n):
        x = 100.0 * i / (n - 1)
        y = 50.0 + 31.0 * math.sin(i * 0.73) + rng.uniform(-12, 12)
        nodes.append((round(x, 3), round(max(0, min(100, y)), 3)))
    return nodes


def make_base_arcs(nodes, rng: random.Random, size_class: str):
    n = len(nodes)
    arcs: dict[tuple[int, int], Arc] = {}
    # Guaranteed bidirectional backbone.
    for i in range(n - 1):
        for u, v in ((i, i + 1), (i + 1, i)):
            c = round(distance(nodes[u], nodes[v]) * rng.uniform(1.08, 1.30), 3)
            arcs[(u, v)] = Arc(u, v, c)
    k = {"S": 3, "M": 5, "L": 7}[size_class]
    for u in range(n):
        nearest = sorted((distance(nodes[u], nodes[v]), v) for v in range(n) if v != u)[:k]
        for euclid, v in nearest:
            if (u, v) not in arcs:
                arcs[(u, v)] = Arc(u, v, round(euclid * rng.uniform(1.10, 1.55), 3))
    return sorted(arcs.values(), key=lambda a: (a.tail, a.head))


def all_pairs_from(n: int, arcs: list[Arc], source: int):
    adj = [[] for _ in range(n)]
    for a in arcs:
        adj[a.tail].append((a.head, a.cost))
    dist = [math.inf] * n
    dist[source] = 0.0
    pq = [(0.0, source)]
    while pq:
        d, u = heapq.heappop(pq)
        if d != dist[u]:
            continue
        for v, c in adj[u]:
            nd = d + c
            if nd < dist[v]:
                dist[v] = nd
                heapq.heappush(pq, (nd, v))
    return dist


def choose_latent_arcs(nodes, base_arcs, count, strength, rng):
    n = len(nodes)
    existing = {(a.tail, a.head) for a in base_arcs}
    candidates = []
    # Seed one demonstrably useful opportunity on the static optimum whenever
    # the path is long enough. Remaining arcs are selected from the controlled
    # geometric opportunity pool and may be useful, neutral, or deceptive.
    _base_cost, base_route = shortest_path(n, base_arcs, 0, n - 1)
    seeded = []
    edge_cost = {(a.tail, a.head): a.cost for a in base_arcs}
    if len(base_route) >= 5:
        for left in range(2, len(base_route) - 2):
            for right in range(len(base_route) - 1, left + 1, -1):
                u, v = base_route[left], base_route[right]
                if (u, v) in existing:
                    continue
                segment = sum(edge_cost[(a, b)] for a, b in zip(base_route[left:right], base_route[left+1:right+1]))
                latent_cost = round(max(distance(nodes[u], nodes[v]), segment * {"weak": .88, "moderate": .72, "strong": .55}[strength]), 3)
                if latent_cost < segment:
                    seeded.append((u, v, latent_cost, (segment - latent_cost) / segment))
                    break
            if seeded:
                break
    for u in range(n - 2):
        dists = all_pairs_from(n, base_arcs, u)
        for v in range(u + 2, min(n, u + max(5, n // 3))):
            if (u, v) in existing or math.isinf(dists[v]):
                continue
            factor = {"weak": 0.88, "moderate": 0.72, "strong": 0.55}[strength]
            latent_cost = round(max(distance(nodes[u], nodes[v]), dists[v] * factor), 3)
            saving = (dists[v] - latent_cost) / dists[v]
            candidates.append((abs(saving - {"weak": .10, "moderate": .24, "strong": .40}[strength]), u, v, latent_cost, saving))
    candidates.sort()
    pool = candidates[: max(count * 8, count)]
    rng.shuffle(pool)
    selected = []
    used = set()
    for u, v, c, saving in seeded:
        selected.append({"id": "L001", "from": u, "to": v, "cost": c,
                         "opportunity_strength": round(saving, 4),
                         "activation_delay": 1, "activation_rules": []})
        used.add((u, v))
    for _, u, v, c, saving in pool:
        if (u, v) not in used:
            selected.append({"id": f"L{len(selected)+1:03d}", "from": u, "to": v,
                             "cost": c, "opportunity_strength": round(saving, 4),
                             "activation_delay": 1, "activation_rules": []})
            used.add((u, v))
        if len(selected) == count:
            break
    if len(selected) < count:
        raise RuntimeError("Insufficient latent arc candidates")
    return selected


def add_activation_rules(latent, base_arcs, avg_k, depth, alternatives, rng):
    forward = [a for a in base_arcs if a.tail < a.head]
    action_pool = [(a.tail, a.head) for a in forward]
    for idx, item in enumerate(latent):
        k = max(2, min(5, avg_k + rng.choice([-1, 0, 0, 1])))
        eligible = [a for a in action_pool if a[1] <= item["from"] + 1]
        if len(eligible) < k:
            eligible = action_pool
        rules = []
        n_rules = 2 if alternatives > 1 and idx % 3 == 0 else 1
        for r in range(n_rules):
            if idx == 0:
                # Use actions on an optimal prefix to create at least one
                # interpretable, reachable activation in each family.
                _d, prefix = shortest_path(max(max(a.tail, a.head) for a in base_arcs) + 1,
                                           base_arcs, 0, item["from"])
                prefix_arcs = list(zip(prefix, prefix[1:]))
                chosen = prefix_arcs[-min(k, len(prefix_arcs)):] if len(prefix_arcs) >= 2 else rng.sample(eligible, min(k, len(eligible)))
            else:
                chosen = rng.sample(eligible, min(k, len(eligible)))
            prereqs = [{"type": "traverse", "arc": list(a)} for a in chosen]
            # Recursive dependencies are introduced only after an earlier latent arc exists.
            if depth > 1 and idx > 0 and idx % 4 == 0:
                prereqs[-1] = {"type": "traverse_latent", "latent_arc_id": latent[idx - 1]["id"]}
            rules.append({"rule_id": f"R{r+1}", "all_of": prereqs})
        item["activation_rules"] = rules


def exact_ceaa(n, base_arcs, latent, source, target, max_actions=22):
    action_keys = []
    for item in latent:
        for rule in item["activation_rules"]:
            for p in rule["all_of"]:
                if p["type"] == "traverse":
                    key = ("B", p["arc"][0], p["arc"][1])
                else:
                    key = ("L", p["latent_arc_id"])
                if key not in action_keys:
                    action_keys.append(key)
    if len(action_keys) > max_actions:
        return None
    bit = {a: 1 << i for i, a in enumerate(action_keys)}
    base_adj = [[] for _ in range(n)]
    for a in base_arcs:
        base_adj[a.tail].append((a.head, a.cost, ("B", a.tail, a.head), None))
    latent_by_id = {x["id"]: x for x in latent}
    latent_adj = [[] for _ in range(n)]
    for x in latent:
        latent_adj[x["from"]].append((x["to"], x["cost"], ("L", x["id"]), x))

    def enabled(item, mask):
        for rule in item["activation_rules"]:
            ok = True
            for p in rule["all_of"]:
                key = ("B", p["arc"][0], p["arc"][1]) if p["type"] == "traverse" else ("L", p["latent_arc_id"])
                ok = ok and bool(mask & bit.get(key, 0))
            if ok:
                return True
        return False

    start = (source, 0)
    dist = {start: 0.0}
    prev = {}
    pq = [(0.0, source, 0)]
    final = None
    while pq:
        d, u, mask = heapq.heappop(pq)
        if d != dist.get((u, mask)):
            continue
        if u == target:
            final = (u, mask)
            break
        transitions = list(base_adj[u])
        transitions += [x for x in latent_adj[u] if enabled(x[3], mask)]
        for v, c, key, _item in transitions:
            nm = mask | bit.get(key, 0)
            nd = round(d + c, 6)
            state = (v, nm)
            if nd < dist.get(state, math.inf):
                dist[state] = nd
                prev[state] = ((u, mask), key)
                heapq.heappush(pq, (nd, v, nm))
    if final is None:
        return None
    route, actions, cur = [final[0]], [], final
    while cur != start:
        old, key = prev[cur]
        route.append(old[0])
        actions.append(key)
        cur = old
    route.reverse(); actions.reverse()
    used_latent = [a[1] for a in actions if a[0] == "L"]
    return {"status": "optimal", "objective": round(dist[final], 3), "route": route,
            "used_latent_arcs": used_latent, "state_actions": len(action_keys)}


def write_csv(path: Path, headers, rows):
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(headers)
        w.writerows(rows)


def write_json(path: Path, obj):
    path.write_text(json.dumps(obj, indent=2) + "\n", encoding="utf-8")


def sha256(path: Path):
    h = hashlib.sha256()
    h.update(path.read_bytes())
    return h.hexdigest()


def create_instance(out, size_class, index, n, latent_count, avg_k, depth, alternatives, strength):
    seed = MASTER_SEED + {"S": 1000, "M": 2000, "L": 3000}[size_class] + index
    rng = random.Random(seed)
    name = f"CEAA-{size_class}-{index:02d}"
    folder = out / "instances" / name
    folder.mkdir(parents=True, exist_ok=True)
    nodes = make_nodes(n, rng)
    base_arcs = make_base_arcs(nodes, rng, size_class)
    latent = choose_latent_arcs(nodes, base_arcs, latent_count, strength, rng)
    add_activation_rules(latent, base_arcs, avg_k, depth, alternatives, rng)
    base_cost, base_route = shortest_path(n, base_arcs, 0, n - 1)
    exact = exact_ceaa(n, base_arcs, latent, 0, n - 1) if size_class == "S" else None
    metadata = {
        "name": name, "problem": "CEAA-RP", "benchmark_version": VERSION,
        "size_class": size_class, "seed": seed, "dimension": n, "origin": 0,
        "destination": n - 1, "directed": True, "base_arc_count": len(base_arcs),
        "latent_arc_count": len(latent), "latent_density": round(len(latent)/(len(base_arcs)+len(latent)), 4),
        "average_prerequisite_target": avg_k, "dependency_depth_target": depth,
        "alternative_rules_target": alternatives, "opportunity_class": strength,
        "cost_units": "synthetic_distance_units", "coordinate_system": "synthetic_2d",
        "activation_semantics": "A latent arc is traversable at the next decision stage after one complete all_of rule has occurred in route history."
    }
    write_csv(folder / "nodes.csv", ["node_id", "x", "y", "role"],
              [(i, x, y, "origin" if i == 0 else "destination" if i == n-1 else "transit") for i, (x, y) in enumerate(nodes)])
    write_csv(folder / "base_arcs.csv", ["from", "to", "cost"],
              [(a.tail, a.head, a.cost) for a in base_arcs])
    write_json(folder / "activation.json", {"schema_version": VERSION, "latent_arcs": latent})
    write_json(folder / "metadata.json", metadata)
    write_json(folder / "baseline_solution.json", {"status": "optimal_static_shortest_path", "objective": round(base_cost, 3), "route": base_route})
    if exact:
        exact["value_of_endogenous_activation"] = round(base_cost - exact["objective"], 3)
        write_json(folder / "ceaa_optimal_solution.json", exact)
    return metadata | {"baseline_cost": round(base_cost, 3), "ceaa_exact_cost": exact["objective"] if exact else "",
                       "vea": exact["value_of_endogenous_activation"] if exact else ""}


def generate(root: Path):
    instances = root / "instances"
    if instances.exists():
        shutil.rmtree(instances)
    instances.mkdir(parents=True)
    rows = []
    sizes = {
        "S": [10, 12, 14, 15, 16, 18, 19, 20, 22, 25],
        "M": [32, 40, 48, 56, 64, 72, 80, 88, 96, 100],
        "L": [120, 150, 180, 210, 240, 280, 320, 350, 380, 400],
    }
    strengths = ["weak", "moderate", "strong"]
    for cls, ns in sizes.items():
        for i, n in enumerate(ns, 1):
            latent_count = max(2, {"S": round(n*.18), "M": round(n*.12), "L": round(n*.08)}[cls])
            rows.append(create_instance(root, cls, i, n, latent_count,
                                        2 + (i % 4), 1 + (i % 3), 1 + (i % 2), strengths[(i-1) % 3]))
    headers = ["name", "size_class", "dimension", "seed", "base_arc_count", "latent_arc_count",
               "latent_density", "average_prerequisite_target", "dependency_depth_target",
               "alternative_rules_target", "opportunity_class", "baseline_cost", "ceaa_exact_cost", "vea"]
    write_csv(root / "benchmark_summary.csv", headers, [[r[h] for h in headers] for r in rows])
    manifest = []
    for path in sorted(root.rglob("*")):
        if path.is_file() and path.name != "MANIFEST.sha256":
            manifest.append(f"{sha256(path)}  {path.relative_to(root).as_posix()}")
    (root / "MANIFEST.sha256").write_text("\n".join(manifest) + "\n", encoding="utf-8")
    return rows


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    result = generate(args.output.resolve())
    print(f"Generated {len(result)} CEAA-RP instances in {args.output.resolve()}")
