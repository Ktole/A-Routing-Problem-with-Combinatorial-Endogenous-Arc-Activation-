# CEAA-Bench v1.0

CEAA-Bench is a reproducible benchmark suite for the **Combinatorial Endogenous Arc Activation Routing Problem (CEAA-RP)** described in *A Routing Problem with Combinatorial Endogenous Arc Activation*.

The suite contains 30 directed single-route origin–destination instances:

| Class | Instances | Nodes | Intended use |
|---|---:|---:|---|
| CEAA-S | 10 | 10–25 | Exact optimization and formulation validation |
| CEAA-M | 10 | 32–100 | Exact/heuristic comparison |
| CEAA-L | 10 | 120–400 | Scalability experiments |

## Defining semantics

Each instance has initially traversable base arcs and latent arcs. A latent arc is unavailable until the route history satisfies at least one activation rule. Every rule is an AND-set of two or more prerequisite traversals; multiple rules implement OR-of-AND logic. Some instances contain recursive rules in which traversal of an earlier latent arc is a prerequisite for a later latent arc.

Activation has a one-stage delay: prerequisites completed at stage `t` make the corresponding latent arc available from stage `t+1`. There is no artificial activation reward; value arises only through reduced downstream route cost.

## Files

Each instance directory contains:

- `nodes.csv`: node identifiers, coordinates and roles.
- `base_arcs.csv`: initially traversable directed arcs and costs.
- `activation.json`: latent arcs, costs and activation rules.
- `metadata.json`: controlled generation parameters and semantics.
- `baseline_solution.json`: optimal static shortest path using base arcs only.
- `ceaa_optimal_solution.json`: exact expanded-state solution for CEAA-S instances.

The root `benchmark_summary.csv` indexes all instances. `MANIFEST.sha256` provides file hashes.

## Reproduce and validate

From the package root:

```bash
python3 scripts/generate_ceaa_bench.py --output .
python3 scripts/validate_ceaa_bench.py .
```

Generation is deterministic under master seed `20260916`. Re-running the generator produces the same instance bytes with the same Python version and standard-library behavior.

## Activation schema

```json
{
  "id": "L001",
  "from": 4,
  "to": 9,
  "cost": 8.25,
  "activation_delay": 1,
  "activation_rules": [
    {
      "rule_id": "R1",
      "all_of": [
        {"type": "traverse", "arc": [0, 1]},
        {"type": "traverse", "arc": [2, 3]}
      ]
    }
  ]
}
```

The route may revisit nodes and arcs. A prerequisite is satisfied once its specified arc has been traversed. History persists for the remainder of the route.

## Recommended reporting

Report static cost, CEAA cost, value of endogenous activation, optimality gap, run time, explored states, activated latent arcs and used latent arcs. Separate results by node count, latent density, prerequisite cardinality, dependency depth, number of alternative rules and opportunity class.

## Scope and limitation

Version 1.0 is a synthetic, controlled benchmark for the single-route directed CEAA-RP. It is not yet a CVRP, VRPTW or real-road dataset. The controlled construction is intentional: it isolates combinatorial activation while supporting exact validation on small cases. A future companion release can layer the activation schema over CVRPLIB or OpenStreetMap data.

## Citation placeholder

Until the article and repository receive permanent identifiers, cite the benchmark as:

> Tole, K. (2026). CEAA-Bench v1.0: Benchmark instances for routing with combinatorial endogenous arc activation.

## License

MIT License. See `LICENSE`.
