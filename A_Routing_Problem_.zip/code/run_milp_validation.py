#!/usr/bin/env python3
"""Independent time-expanded MILP validation of CEAA-RP using SciPy/HiGHS."""
from __future__ import annotations
import argparse, csv, json, time
from pathlib import Path
import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import coo_matrix
from run_experiments import load_instance, solve


class Model:
    def __init__(self):
        self.c=[]; self.lo=[]; self.hi=[]; self.integrality=[]
        self.ri=[]; self.ci=[]; self.val=[]; self.lb=[]; self.ub=[]
    def var(self, cost=0.0):
        i=len(self.c); self.c.append(cost); self.lo.append(0.0); self.hi.append(1.0); self.integrality.append(1); return i
    def row(self, terms, lb=-np.inf, ub=np.inf):
        r=len(self.lb)
        for j,a in terms.items():
            if abs(a)>1e-14: self.ri.append(r); self.ci.append(j); self.val.append(a)
        self.lb.append(lb); self.ub.append(ub)
    def solve(self, time_limit):
        A=coo_matrix((self.val,(self.ri,self.ci)),shape=(len(self.lb),len(self.c))).tocsr()
        return milp(np.asarray(self.c),integrality=np.asarray(self.integrality),bounds=Bounds(self.lo,self.hi),
                    constraints=LinearConstraint(A,self.lb,self.ub),
                    options={'time_limit':time_limit,'mip_rel_gap':0.0,'presolve':True})


def validate(folder: Path, time_limit: float):
    meta,nodes,base,latent=load_instance(folder)
    n=meta['dimension']; s=meta['origin']; d=meta['destination']
    # The horizon safely accommodates the simple backbone plus all generated detours.
    H=2*n+2*int(meta.get('prerequisite_count',5))+5
    arcs=[(u,v,c,'B',f'{u}:{v}') for u,v,c in base]
    arcs += [(e['from'],e['to'],e['cost'],'L',e['id']) for e in latent]
    arcs.append((d,d,0.0,'W','wait'))
    action_keys=[]
    for e in latent:
        for rule in e['activation_rules']:
            for p in rule['all_of']:
                q=('B',p['arc'][0],p['arc'][1]) if p['type']=='traverse' else ('L',p['latent_arc_id'])
                if q not in action_keys: action_keys.append(q)
    action_arcs={q:[] for q in action_keys}
    for a,(u,v,c,typ,ident) in enumerate(arcs):
        qb=('B',u,v); ql=('L',ident)
        if qb in action_arcs: action_arcs[qb].append(a)
        if ql in action_arcs: action_arcs[ql].append(a)
    M=Model()
    x={(a,t):M.var(arcs[a][2]) for a in range(len(arcs)) for t in range(H)}
    p={(i,t):M.var() for i in range(n) for t in range(H+1)}
    z={(q,t):M.var() for q in action_keys for t in range(H+1)}
    w={}; y={}
    for ei,e in enumerate(latent):
        for t in range(H):
            y[ei,t]=M.var()
            for k,_ in enumerate(e['activation_rules']): w[ei,k,t]=M.var()
    for i in range(n): M.row({p[i,0]:1},1 if i==s else 0,1 if i==s else 0)
    out={i:[] for i in range(n)}; inc={i:[] for i in range(n)}
    for a,(u,v,*_) in enumerate(arcs): out[u].append(a); inc[v].append(a)
    for t in range(H):
        for i in range(n):
            terms={p[i,t]:-1}; terms.update({x[a,t]:1 for a in out[i]}); M.row(terms,0,0)
            terms={p[i,t+1]:-1}; terms.update({x[a,t]:1 for a in inc[i]}); M.row(terms,0,0)
    M.row({p[d,H]:1},1,1)
    for q in action_keys:
        M.row({z[q,0]:1},0,0)
        for t in range(H):
            M.row({z[q,t+1]:1,z[q,t]:-1},0,np.inf)
            for a in action_arcs[q]: M.row({z[q,t+1]:1,x[a,t]:-1},0,np.inf)
            terms={z[q,t+1]:1,z[q,t]:-1}; terms.update({x[a,t]:-1 for a in action_arcs[q]})
            M.row(terms,-np.inf,0)
    qindex={q:q for q in action_keys}
    for ei,e in enumerate(latent):
        for t in range(H):
            for k,rule in enumerate(e['activation_rules']):
                prereq=[]
                for item in rule['all_of']:
                    q=('B',item['arc'][0],item['arc'][1]) if item['type']=='traverse' else ('L',item['latent_arc_id'])
                    prereq.append(qindex[q])
                for q in prereq: M.row({w[ei,k,t]:1,z[q,t]:-1},-np.inf,0)
                terms={w[ei,k,t]:1}; terms.update({z[q,t]:-1 for q in prereq})
                M.row(terms,1-len(prereq),np.inf)
                M.row({y[ei,t]:1,w[ei,k,t]:-1},0,np.inf)
            terms={y[ei,t]:1}; terms.update({w[ei,k,t]:-1 for k in range(len(e['activation_rules']))})
            M.row(terms,-np.inf,0)
            for a,arc in enumerate(arcs):
                if arc[3]=='L' and arc[4]==e['id']: M.row({x[a,t]:1,y[ei,t]:-1},-np.inf,0)
    started=time.perf_counter(); res=M.solve(time_limit); elapsed=time.perf_counter()-started
    aads=solve(folder,None,time_limit,True,.02)
    obj=float(res.fun) if res.fun is not None else None
    return {'instance':meta['name'],'nodes':n,'horizon':H,'milp_status':int(res.status),
            'milp_message':res.message,'milp_objective':round(obj,6) if obj is not None else None,
            'aads_objective':aads['aads'],'absolute_difference':round(abs(obj-aads['aads']),6) if obj is not None else None,
            'milp_runtime_s':round(elapsed,6),'milp_variables':len(M.c),'milp_constraints':len(M.lb)}


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--project',type=Path,required=True); ap.add_argument('--output',type=Path,required=True); ap.add_argument('--time-limit',type=float,default=120); a=ap.parse_args()
    folders=list(sorted((a.project/'CEAA-Bench-v1.0'/'instances').glob('CEAA-S-*')))
    folders+=list(sorted(x for x in (a.project/'CEAA-Synergy-v2').glob('SYN-N20-*') if x.is_dir()))
    rows=[]
    for f in folders:
        r=validate(f,a.time_limit); rows.append(r); print(r['instance'],r['milp_objective'],r['aads_objective'],r['milp_status'])
    a.output.mkdir(parents=True,exist_ok=True)
    with (a.output/'milp_validation.csv').open('w',newline='') as fh:
        w=csv.DictWriter(fh,fieldnames=rows[0]); w.writeheader(); w.writerows(rows)
    summary={'instances':len(rows),'milp_optimal':sum(r['milp_status']==0 for r in rows),
             'matched_aads':sum(r['absolute_difference'] is not None and r['absolute_difference']<=1e-5 for r in rows),
             'max_absolute_difference':max(r['absolute_difference'] for r in rows if r['absolute_difference'] is not None)}
    (a.output/'milp_validation_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
if __name__=='__main__': main()
