#!/usr/bin/env python3
"""Create an application-grounded Mombasa emergency-access CEAA case."""
from __future__ import annotations
import csv, json
from pathlib import Path
from run_experiments import solve

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'case_study'/'Mombasa-emergency-access'
OUT.mkdir(parents=True,exist_ok=True)
nodes=[
 (0,0,0,'Operations centre'),(1,2,1,'CBD staging point'),(2,4,0,'Makupa junction'),
 (3,7,1,'Changamwe junction'),(4,10,0,'Jomvu junction'),(5,13,0,'Emergency shelter'),
 (6,4,3,'Supply cache'),(7,7,4,'Bridge inspection'),(8,10,3,'Access-control post'),
 (9,8,-2,'Alternative holding point')]
arcs=[(0,1,6),(1,2,5),(2,3,7),(3,4,8),(4,5,35),
      (2,6,3),(6,2,3),(3,7,4),(7,3,4),(4,8,2),(8,4,2),
      (3,9,12),(9,4,12)]
latent=[{'id':'EC01','from':4,'to':5,'cost':4.0,'opportunity_strength':0.51,'activation_delay':1,
 'operational_interpretation':'Emergency corridor authorised only after supply positioning, bridge inspection, and access-control clearance.',
 'activation_rules':[{'rule_id':'R1','all_of':[{'type':'traverse','arc':[2,6]},
                                              {'type':'traverse','arc':[3,7]},
                                              {'type':'traverse','arc':[4,8]}]}]}]
with (OUT/'nodes.csv').open('w',newline='') as f:
 w=csv.writer(f); w.writerow(['node_id','x','y','role']); w.writerows(nodes)
with (OUT/'base_arcs.csv').open('w',newline='') as f:
 w=csv.writer(f); w.writerow(['from','to','cost']); w.writerows(arcs)
(OUT/'activation.json').write_text(json.dumps({'schema_version':'2.0.0','latent_arcs':latent},indent=2)+'\n')
(OUT/'metadata.json').write_text(json.dumps({'name':'MOMBASA-EA-01','problem':'CEAA-RP','benchmark_version':'case-1.0',
 'size_class':'CASE','dimension':10,'origin':0,'destination':5,'directed':True,'base_arc_count':len(arcs),
 'latent_arc_count':1,'prerequisite_count':3,'dependency_depth':1,'units':'minutes',
 'case_status':'application-grounded illustrative scenario; not field-calibrated'},indent=2)+'\n')
r=solve(OUT,None,30,True,.02)
(OUT/'solution.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r,indent=2))
