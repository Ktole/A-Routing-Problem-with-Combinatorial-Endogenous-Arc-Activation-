#!/usr/bin/env python3
"""Run activation-aware dominance search on CEAA-Bench v1.0.

The algorithm is exact when no resource cap is imposed. For larger instances,
it applies a per-node nondominated-label cap and returns a feasible upper bound.
"""

from __future__ import annotations

import argparse
import csv
import heapq
import json
import math
import time
from pathlib import Path


def load_instance(folder: Path):
    meta = json.loads((folder / "metadata.json").read_text())
    act = json.loads((folder / "activation.json").read_text())
    with (folder / "nodes.csv").open(newline="") as f:
        nodes = {int(r["node_id"]): (float(r["x"]), float(r["y"])) for r in csv.DictReader(f)}
    with (folder / "base_arcs.csv").open(newline="") as f:
        base = [(int(r["from"]), int(r["to"]), float(r["cost"])) for r in csv.DictReader(f)]
    return meta, nodes, base, act["latent_arcs"]


def static_shortest(n, arcs, s, t):
    adj = [[] for _ in range(n)]
    for u, v, c in arcs:
        adj[u].append((v, c))
    d = [math.inf] * n; d[s] = 0.0
    prev = [-1] * n; pq = [(0.0, s)]
    while pq:
        g, u = heapq.heappop(pq)
        if g != d[u]: continue
        if u == t: break
        for v, c in adj[u]:
            ng = g + c
            if ng < d[v]:
                d[v], prev[v] = ng, u
                heapq.heappush(pq, (ng, v))
    route = []; u = t
    while u >= 0:
        route.append(u); u = prev[u]
    return d[t], route[::-1]


def solve(folder: Path, label_cap: int | None, time_limit: float, dominance: bool = True, history_bonus: float = 0.02):
    meta, nodes, base, latent = load_instance(folder)
    n, s, target = meta["dimension"], meta["origin"], meta["destination"]
    baseline, baseline_route = static_shortest(n, base, s, target)

    action_keys = []
    for item in latent:
        for rule in item["activation_rules"]:
            for p in rule["all_of"]:
                key = ("B", p["arc"][0], p["arc"][1]) if p["type"] == "traverse" else ("L", p["latent_arc_id"])
                if key not in action_keys: action_keys.append(key)
    bit = {a: 1 << i for i, a in enumerate(action_keys)}
    base_adj = [[] for _ in range(n)]
    for u, v, c in base:
        base_adj[u].append((v, c, ("B", u, v), None))
    latent_adj = [[] for _ in range(n)]
    for item in latent:
        latent_adj[item["from"]].append((item["to"], item["cost"], ("L", item["id"]), item))

    def enabled(item, mask):
        for rule in item["activation_rules"]:
            if all(mask & bit.get(("B", p["arc"][0], p["arc"][1]) if p["type"] == "traverse" else ("L", p["latent_arc_id"]), 0)
                   for p in rule["all_of"]):
                return True
        return False

    def heuristic(u):
        x1, y1 = nodes[u]; x2, y2 = nodes[target]
        return math.hypot(x1-x2, y1-y2)

    labels = [[] for _ in range(n)]  # (mask, cost, label_id)
    records = [(s, 0, 0.0, None, None)]
    labels[s].append((0, 0.0, 0))
    pq = [(heuristic(s), 0.0, 0)]
    best_id = None; best_cost = baseline
    generated = 1; expanded = 0; pruned = 0; capped = 0
    started = time.perf_counter()

    timed_out = False
    while pq:
        if time.perf_counter() - started > time_limit:
            timed_out = True
            break
        _f, g, lid = heapq.heappop(pq)
        u, mask, saved_g, _parent, _move = records[lid]
        if g != saved_g: continue
        if g + heuristic(u) >= best_cost - 1e-9: continue
        if not any(x[2] == lid for x in labels[u]): continue
        expanded += 1
        transitions = list(base_adj[u])
        transitions.extend(x for x in latent_adj[u] if enabled(x[3], mask))
        for v, c, key, _item in transitions:
            ng = g + c
            if ng + heuristic(v) >= best_cost - 1e-9:
                pruned += 1; continue
            nm = mask | bit.get(key, 0)
            # A cheaper label with a superset history dominates this label.
            if dominance and any(old_g <= ng + 1e-9 and (old_mask | nm) == old_mask for old_mask, old_g, _ in labels[v]):
                pruned += 1; continue
            if dominance:
                labels[v] = [(om, og, oi) for om, og, oi in labels[v]
                             if not (ng <= og + 1e-9 and (nm | om) == nm)]
            elif any(om == nm and og <= ng + 1e-9 for om, og, _ in labels[v]):
                pruned += 1; continue
            nid = len(records)
            records.append((v, nm, ng, lid, key)); generated += 1
            labels[v].append((nm, ng, nid))
            if label_cap and len(labels[v]) > label_cap:
                labels[v].sort(key=lambda x: x[1] + heuristic(v) - history_bonus * x[0].bit_count())
                dropped = labels[v][label_cap:]
                labels[v] = labels[v][:label_cap]
                capped += len(dropped)
                if not any(x[2] == nid for x in labels[v]): continue
            if v == target:
                best_cost, best_id = ng, nid
            else:
                heapq.heappush(pq, (ng + heuristic(v), ng, nid))

    if best_id is None:
        route, used = baseline_route, []
        status = "baseline_returned"
    else:
        route, used, cur = [], [], best_id
        while cur is not None:
            u, _m, _g, parent, move = records[cur]
            route.append(u)
            if move and move[0] == "L": used.append(move[1])
            cur = parent
        route.reverse(); used.reverse()
        status = "optimal" if (not timed_out and not pq and capped == 0) else "feasible"
    runtime = time.perf_counter() - started
    return {
        "instance": meta["name"], "class": meta["size_class"], "nodes": n,
        "base_arcs": meta["base_arc_count"], "latent_arcs": meta["latent_arc_count"],
        "actions": len(action_keys), "baseline": round(baseline, 3),
        "aads": round(best_cost, 3), "vea": round(baseline-best_cost, 3),
        "improvement_pct": round(100*(baseline-best_cost)/baseline, 3),
        "runtime_s": round(runtime, 6), "expanded": expanded, "generated": generated,
        "dominance_or_bound_pruned": pruned, "cap_dropped": capped,
        "used_latent_count": len(used), "used_latent_arcs": used,
        "route": route, "status": status, "label_cap": label_cap or "none",
        "dominance": dominance, "history_bonus": history_bonus
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--bench", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--time-limit", type=float, default=30.0)
    args = p.parse_args()
    rows = []
    for folder in sorted((args.bench / "instances").iterdir()):
        if not folder.is_dir(): continue
        cls = folder.name.split("-")[1]
        cap = None if cls == "S" else (250 if cls == "M" else 80)
        row = solve(folder, cap, args.time_limit)
        rows.append(row)
        print(row["instance"], row["aads"], row["status"], row["runtime_s"])
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "detailed_results.json").write_text(json.dumps(rows, indent=2) + "\n")
    fields = [k for k in rows[0] if k not in {"route", "used_latent_arcs"}]
    with (args.output / "results.csv").open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields); w.writeheader()
        for r in rows: w.writerow({k: r[k] for k in fields})
    summary = {}
    for cls in "SML":
        group = [r for r in rows if r["class"] == cls]
        summary[cls] = {
            "instances": len(group),
            "mean_improvement_pct": round(sum(r["improvement_pct"] for r in group)/len(group), 3),
            "mean_runtime_s": round(sum(r["runtime_s"] for r in group)/len(group), 6),
            "improved_instances": sum(r["vea"] > 0 for r in group),
            "mean_expanded": round(sum(r["expanded"] for r in group)/len(group), 1),
        }
    (args.output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")


if __name__ == "__main__":
    main()
