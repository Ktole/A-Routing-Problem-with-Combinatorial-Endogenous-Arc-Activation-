#!/usr/bin/env python3
"""Factorial CEAA experiments with baselines, dominance ablation and statistics."""
from __future__ import annotations
import argparse,csv,json,statistics,time
from pathlib import Path
from scipy.stats import wilcoxon, friedmanchisquare, spearmanr
from run_experiments import solve, load_instance, static_shortest

def main():
    p=argparse.ArgumentParser(); p.add_argument('--suite',type=Path,required=True); p.add_argument('--output',type=Path,required=True); a=p.parse_args()
    a.output.mkdir(parents=True,exist_ok=True)
    rows=[]; ablations=[]
    for folder in sorted(x for x in a.suite.iterdir() if x.is_dir()):
        meta=json.loads((folder/'metadata.json').read_text())
        n=meta['dimension']; cap=None if n<=100 else 2000
        exact=solve(folder,cap,30,True,.02)
        nodom=solve(folder,cap,30,False,.02)
        nohist=solve(folder,cap,30,True,0.0)
        exact.update({k:meta[k] for k in ('prerequisite_count','dependency_depth','opportunity_class','planted_target_improvement')})
        exact['static']=exact['baseline']; exact['myopic']=exact['baseline']
        _m,_nodes,base,latent=load_instance(folder)
        all_arcs=base+[(x['from'],x['to'],x['cost']) for x in latent]
        lb,_=static_shortest(n,all_arcs,meta['origin'],meta['destination'])
        exact['optimistic_lb']=round(lb,3)
        exact['gap_to_optimistic_lb_pct']=round(100*(exact['aads']-exact['optimistic_lb'])/exact['aads'],3)
        rows.append(exact)
        ablations.append({'instance':meta['name'],'nodes':n,'dominance_expanded':exact['expanded'],
          'no_dominance_expanded':nodom['expanded'],'dominance_generated':exact['generated'],
          'no_dominance_generated':nodom['generated'],'history_bonus_objective':exact['aads'],
          'zero_bonus_objective':nohist['aads'],'history_bonus_cap_dropped':exact['cap_dropped'],
          'zero_bonus_cap_dropped':nohist['cap_dropped']})
        print(meta['name'],exact['improvement_pct'],exact['status'],exact['expanded'],nodom['expanded'])
    fields=[k for k in rows[0] if k not in ('route','used_latent_arcs')]
    with (a.output/'factorial_results.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows({k:r[k] for k in fields} for r in rows)
    with (a.output/'ablation_results.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=ablations[0]);w.writeheader();w.writerows(ablations)
    by_strength={}
    for s in ('weak','moderate','strong'):
        g=[r for r in rows if r['opportunity_class']==s]
        by_strength[s]={'n':len(g),'mean_improvement_pct':round(statistics.mean(r['improvement_pct'] for r in g),3),
          'median_improvement_pct':round(statistics.median(r['improvement_pct'] for r in g),3),
          'mean_expanded':round(statistics.mean(r['expanded'] for r in g),1),'optimal':sum(r['status']=='optimal' for r in g)}
    diffs=[r['static']-r['aads'] for r in rows]
    stat,pw=wilcoxon(diffs,alternative='greater',zero_method='wilcox')
    fstat,pf=friedmanchisquare([r['static'] for r in rows],[r['myopic'] for r in rows],[r['aads'] for r in rows])
    rho,pr=spearmanr([r['prerequisite_count'] for r in rows],[r['expanded'] for r in rows])
    ratios=[b['no_dominance_expanded']/max(1,b['dominance_expanded']) for b in ablations]
    summary={'instances':len(rows),'optimal':sum(r['status']=='optimal' for r in rows),'by_strength':by_strength,
      'wilcoxon_static_minus_aads':{'W':float(stat),'p':float(pw)},'friedman':{'chi2':float(fstat),'p':float(pf)},
      'spearman_prerequisites_vs_expanded':{'rho':float(rho),'p':float(pr)},
      'dominance_expansion_ratio_median':round(statistics.median(ratios),3),
      'dominance_expansion_ratio_mean':round(statistics.mean(ratios),3),
      'history_bonus_changed_objective':sum(b['history_bonus_objective']!=b['zero_bonus_objective'] for b in ablations)}
    (a.output/'strengthened_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    (a.output/'factorial_detailed.json').write_text(json.dumps(rows,indent=2)+'\n')
if __name__=='__main__': main()
