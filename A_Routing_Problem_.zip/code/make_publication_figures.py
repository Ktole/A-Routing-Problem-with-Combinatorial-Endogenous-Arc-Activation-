#!/usr/bin/env python3
"""Generate publication-quality CEAA-RP statistical and case-study figures."""
from pathlib import Path
import csv,json
import matplotlib.pyplot as plt
import numpy as np

ROOT=Path(__file__).resolve().parents[1]; FIG=ROOT/'figures'; FIG.mkdir(exist_ok=True)
plt.rcParams.update({'font.size':9,'axes.titlesize':10,'axes.labelsize':9,'figure.dpi':180})
with (ROOT/'results/strengthened/factorial_results.csv').open() as f: rows=list(csv.DictReader(f))
with (ROOT/'results/strengthened/ablation_results.csv').open() as f: abl=list(csv.DictReader(f))
with (ROOT/'results/milp_validation/milp_validation.csv').open() as f: milp=list(csv.DictReader(f))
strengths=['weak','moderate','strong']; colors=['#4c78a8','#f58518','#54a24b']
fig,ax=plt.subplots(2,2,figsize=(10,7),constrained_layout=True)
data=[[float(r['improvement_pct']) for r in rows if r['opportunity_class']==s] for s in strengths]
b=ax[0,0].boxplot(data,tick_labels=[s.title() for s in strengths],patch_artist=True,medianprops={'color':'black'})
for p,c in zip(b['boxes'],colors): p.set_facecolor(c); p.set_alpha(.78)
ax[0,0].set(title='Savings by opportunity class',ylabel='Improvement over static route (%)'); ax[0,0].grid(axis='y',alpha=.25)
for s,c in zip(strengths,colors):
 g=[r for r in rows if r['opportunity_class']==s]; ns=sorted({int(r['nodes']) for r in g})
 means=[np.mean([float(r['expanded']) for r in g if int(r['nodes'])==n]) for n in ns]
 ax[0,1].plot(ns,means,marker='o',label=s.title(),color=c)
ax[0,1].set(title='Search effort as network size grows',xlabel='Nodes',ylabel='Mean labels expanded'); ax[0,1].set_yscale('log'); ax[0,1].legend(frameon=False); ax[0,1].grid(alpha=.25)
ratios=[float(r['no_dominance_expanded'])/max(1,float(r['dominance_expanded'])) for r in abl]
ax[1,0].hist(ratios,bins=10,color='#72b7b2',edgecolor='white'); ax[1,0].axvline(np.mean(ratios),color='#e45756',ls='--',label=f'Mean = {np.mean(ratios):.3f}')
ax[1,0].set(title='Cost of disabling history dominance',xlabel='No-dominance / dominance expansions',ylabel='Instances'); ax[1,0].legend(frameon=False)
x=np.array([float(r['milp_objective']) for r in milp]); y=np.array([float(r['aads_objective']) for r in milp])
ax[1,1].scatter(x,y,s=28,color='#b279a2',alpha=.85); lo=min(x.min(),y.min()); hi=max(x.max(),y.max()); ax[1,1].plot([lo,hi],[lo,hi],color='black',lw=1,ls='--')
ax[1,1].set(title='Independent exact-solver agreement',xlabel='HiGHS MILP objective',ylabel='AADS objective'); ax[1,1].grid(alpha=.25)
fig.savefig(FIG/'statistical_results.pdf',bbox_inches='tight'); fig.savefig(FIG/'statistical_results.png',bbox_inches='tight'); plt.close(fig)

case=ROOT/'case_study/Mombasa-emergency-access'
with (case/'nodes.csv').open() as f: nd={int(r['node_id']):r for r in csv.DictReader(f)}
with (case/'base_arcs.csv').open() as f: arcs=list(csv.DictReader(f))
act=json.loads((case/'activation.json').read_text())['latent_arcs'][0]; sol=json.loads((case/'solution.json').read_text())
fig,ax=plt.subplots(figsize=(10.5,5.2),constrained_layout=True)
for a in arcs:
 u,v=int(a['from']),int(a['to']); x1,y1=float(nd[u]['x']),float(nd[u]['y']); x2,y2=float(nd[v]['x']),float(nd[v]['y'])
 ax.annotate('',(x2,y2),(x1,y1),arrowprops={'arrowstyle':'->','color':'#bbbbbb','lw':1,'alpha':.7})
route=list(zip(sol['route'][:-1],sol['route'][1:]))
for u,v in route:
 x1,y1=float(nd[u]['x']),float(nd[u]['y']); x2,y2=float(nd[v]['x']),float(nd[v]['y'])
 col='#e45756' if (u,v)==(act['from'],act['to']) else '#1f77b4'; ax.annotate('',(x2,y2),(x1,y1),arrowprops={'arrowstyle':'->','color':col,'lw':2.8})
for i,r in nd.items():
 ax.scatter(float(r['x']),float(r['y']),s=145,color='#54a24b' if i in (6,7,8) else '#4c78a8',
            edgecolor='white',linewidth=.8,zorder=3)
 ax.text(float(r['x']),float(r['y']),str(i),ha='center',va='center',fontsize=8,color='white',weight='bold',zorder=4)
legend='\n'.join(f"{i}: {nd[i]['role']}" for i in sorted(nd))
ax.text(1.015,.50,legend,transform=ax.transAxes,va='center',ha='left',fontsize=8,
        bbox={'boxstyle':'round,pad=.55','facecolor':'#f7f7f7','edgecolor':'#999999'})
ax.text(.01,.98,'Selected base arc',transform=ax.transAxes,color='#1f77b4',va='top',fontsize=8,weight='bold')
ax.text(.01,.92,'Activated corridor',transform=ax.transAxes,color='#e45756',va='top',fontsize=8,weight='bold')
ax.set_title(f"Emergency-access route: 61 min static versus {sol['aads']:.0f} min CEAA ({sol['improvement_pct']:.1f}% reduction)",pad=12)
ax.set_xlabel('Illustrative west-east position'); ax.set_ylabel('Operational branch position'); ax.set_xticks([]); ax.set_yticks([]); ax.spines[:].set_visible(False)
fig.savefig(FIG/'case_study_network.pdf',bbox_inches='tight'); fig.savefig(FIG/'case_study_network.png',bbox_inches='tight'); plt.close(fig)
print('Wrote publication figures')
