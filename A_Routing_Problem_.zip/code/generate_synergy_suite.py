#!/usr/bin/env python3
"""Generate a factorial CEAA suite with genuinely synergistic detour actions."""

from __future__ import annotations
import argparse, csv, json, math, random, shutil
from pathlib import Path

MASTER_SEED = 20260917

def dump_json(p, x): p.write_text(json.dumps(x, indent=2)+"\n")
def dump_csv(p, head, rows):
    with p.open("w", newline="") as f:
        w=csv.writer(f); w.writerow(head); w.writerows(rows)

def generate_one(root: Path, n: int, strength: str, rep: int):
    seed=MASTER_SEED+n*100+rep*10+{"weak":1,"moderate":2,"strong":3}[strength]
    rng=random.Random(seed)
    k={20:2,50:3,100:3,200:4}[n]
    m=n-k
    name=f"SYN-N{n}-{strength[0].upper()}-R{rep:02d}"
    out=root/name; out.mkdir(parents=True)
    nodes=[]
    for i in range(m): nodes.append((i,round(8*math.sin(i*.35),3),"origin" if i==0 else "destination" if i==m-1 else "transit"))
    checkpoints=[max(1,round((j+1)*0.16*m)) for j in range(k)]
    for j in range(k): nodes.append((checkpoints[j]+.2,15+5*j,"action"))
    arcs=[]; chain=[]
    for i in range(m-1):
        c=round(rng.uniform(8.0,12.0),3); chain.append(c)
        arcs += [(i,i+1,c),(i+1,i,round(c*1.05,3))]
    # Non-improving skip arcs add realistic choices without changing the base optimum.
    prefix=[0.0]
    for c in chain: prefix.append(prefix[-1]+c)
    for i in range(m-3):
        if rng.random()<0.45:
            j=min(m-1,i+rng.choice([2,3]))
            arcs.append((i,j,round((prefix[j]-prefix[i])*rng.uniform(1.01,1.12),3)))
    actions=[]; detour=0.0
    for j,cp in enumerate(checkpoints):
        b=m+j; c1=round(rng.uniform(.8,1.5),3); c2=round(rng.uniform(.8,1.5),3)
        arcs += [(cp,b,c1),(b,cp,c2)]; detour += c1+c2
        actions.append([cp,b])
    base=prefix[-1]
    u=max(checkpoints)+1; v=min(m-2,round(.70*m))
    target={"weak":.08,"moderate":.20,"strong":.35}[strength]
    desired=base*(1-target)
    prefix_u=prefix[u]
    recursive=(rep%2==0)
    latent=[]
    if recursive:
        total_lat=max(1.0,desired-prefix_u-detour)
        first=round(total_lat*.58,3); second=round(total_lat-first,3)
        latent.append({"id":"L001","from":u,"to":v,"cost":first,"opportunity_strength":target,
                       "activation_delay":1,"activation_rules":[{"rule_id":"R1","all_of":[{"type":"traverse","arc":a} for a in actions]}]})
        latent.append({"id":"L002","from":v,"to":m-1,"cost":second,"opportunity_strength":target,
                       "activation_delay":1,"activation_rules":[{"rule_id":"R1","all_of":[{"type":"traverse_latent","latent_arc_id":"L001"},{"type":"traverse","arc":actions[-1]}]}]})
    else:
        cost=round(max(1.0,desired-prefix_u-detour),3)
        latent.append({"id":"L001","from":u,"to":m-1,"cost":cost,"opportunity_strength":target,
                       "activation_delay":1,"activation_rules":[{"rule_id":"R1","all_of":[{"type":"traverse","arc":a} for a in actions]}]})
    # A deceptive latent arc: reachable only after one action but not worth its detour.
    dcp=checkpoints[0]
    latent.append({"id":"LD01","from":dcp,"to":min(m-1,dcp+2),
                   "cost":round(prefix[min(m-1,dcp+2)]-prefix[dcp]+3.0,3),
                   "opportunity_strength":-0.05,"activation_delay":1,
                   "activation_rules":[{"rule_id":"R1","all_of":[{"type":"traverse","arc":actions[0]},{"type":"traverse","arc":[nodes[-1][0] if False else dcp,m]}]}]})
    # Replace the artificial second deceptive prerequisite with a real branch action.
    latent[-1]["activation_rules"][0]["all_of"][1]={"type":"traverse","arc":actions[min(1,len(actions)-1)]}
    dump_csv(out/"nodes.csv",["node_id","x","y","role"],[(i,*p) for i,p in enumerate(nodes)])
    dump_csv(out/"base_arcs.csv",["from","to","cost"],arcs)
    dump_json(out/"activation.json",{"schema_version":"2.0.0","latent_arcs":latent})
    dump_json(out/"metadata.json",{"name":name,"problem":"CEAA-RP","benchmark_version":"2.0.0-synergy",
      "size_class":f"N{n}","seed":seed,"dimension":n,"origin":0,"destination":m-1,"directed":True,
      "base_arc_count":len(arcs),"latent_arc_count":len(latent),"prerequisite_count":k,
      "dependency_depth":2 if recursive else 1,"opportunity_class":strength,
      "planted_target_improvement":target,"synergy_design":True})
    dump_json(out/"baseline_solution.json",{"status":"optimal_static_shortest_path","objective":round(base,3),"route":list(range(m))})

def main():
    p=argparse.ArgumentParser(); p.add_argument("--output",type=Path,required=True); a=p.parse_args()
    if a.output.exists(): shutil.rmtree(a.output)
    a.output.mkdir(parents=True)
    for n in (20,50,100,200):
        for strength in ("weak","moderate","strong"):
            for rep in range(1,6): generate_one(a.output,n,strength,rep)
    print("Generated 60 factorial synergy instances")
if __name__=="__main__": main()
