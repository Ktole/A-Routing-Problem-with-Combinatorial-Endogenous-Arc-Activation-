Dear Editor-in-Chief,

Please consider the manuscript, “A Routing Problem with Combinatorial Endogenous Arc Activation,” for publication as an original research article.

The paper studies a deterministic routing problem in which combinations of prior traversal actions change the future feasible network. Unlike fixed-charge network design, arc availability is not purchased directly; unlike the Canadian traveller problem, feasibility is not merely revealed; and unlike conventional road-restoration routing, prerequisites need not constitute repairs of the activated arc. The central mechanism is a routing-history-dependent OR-of-AND activation function.

The manuscript provides a time-expanded mixed-integer formulation, an activation-induced NP-hardness proof, structural results for activation viability and label dominance, and an activation-aware dominance search algorithm. Two reproducible suites contain 90 instances. The algorithm certifies 89 solutions, and an independently implemented SciPy/HiGHS MILP proves optimality and exactly matches the algorithm on 25 validation instances. A controlled factorial experiment, dominance ablation, nonparametric statistical analysis, publication figures, and an application-grounded emergency-access illustration are included. Code, data, generators, raw results and reproduction instructions accompany the submission.

This manuscript is original, is not under consideration elsewhere, and has been approved by the author. The author declares no competing interests and no specific funding for this research.

Thank you for considering the manuscript.

Sincerely,

Dr. Kevin Tole  
Institute of Computing and Informatics  
Technical University of Mombasa, Kenya  
Email: Ktole@tum.ac.ke  
ORCID: 0000-0003-0373-3691
